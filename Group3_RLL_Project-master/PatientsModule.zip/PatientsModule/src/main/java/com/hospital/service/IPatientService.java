package com.hospital.service;


import java.util.List;

import com.hospital.entity.Patients;

public interface IPatientService {

	Patients addNewPatient(Patients patients);
	List<Patients> getAllPatients();
	Patients updatePatientPwd(Patients patients);
	Patients updatePatientsDetails(Patients patients);
	void removePatientDetails(int id);
	Patients getPatientsByid(int id);
	
	
}
