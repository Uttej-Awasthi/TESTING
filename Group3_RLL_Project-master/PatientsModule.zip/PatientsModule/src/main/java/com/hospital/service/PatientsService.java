package com.hospital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hospital.entity.Patients;
import com.hospital.repository.PatientsRepo;
import com.hospital.vo.Appointment;
import com.hospital.vo.Invoices;
import com.hospital.vo.ResponseTemplateVo;

@Service("patientsService")
public class PatientsService implements IPatientService {

	
	@Autowired
	@Qualifier("patientsRepository")
	PatientsRepo prepo;
	
	@Autowired
	RestTemplate rest;
	
	@Override
	public Patients addNewPatient(Patients patients){
	
		return prepo.save(patients);
	}
	
	@Override
	public List<Patients> getAllPatients(){
		return prepo.findAll();
	}
	
	@Override
	public Patients updatePatientPwd(Patients patients){
		Patients p1=prepo.findById(patients.getP_id()).get();
		p1.setP_password(patients.getP_password());
		prepo.save(p1);
		return p1;
	}
	
	@Override
	public Patients updatePatientsDetails(Patients patients){
		Patients p2=prepo.findById(patients.getP_id()).get();
		p2.setP_name(patients.getP_name());
		p2.setP_age(patients.getP_age());
		p2.setP_email(patients.getP_email());
		p2.setP_location(patients.getP_location());
		prepo.save(p2);
		return p2;
	}
	
	@Override
	public void removePatientDetails(int id){
		prepo.deleteById(id);
	}

	
	@Override
	public Patients getPatientsByid(int id) {
		return prepo.findById(id).get();
	}
	

	public ResponseTemplateVo getAppointmentDetails(int id){
		ResponseTemplateVo res=new ResponseTemplateVo();
		Patients pat=prepo.findById(id).get();
		Appointment app=rest.getForObject("http://localhost:8083/appointment/gtap/" + pat.getAid(), Appointment.class);
		res.setPat(pat);
		res.setApp(app);
		return res;
		
	}
	
	public ResponseTemplateVo getBillingDetailsById(int id) {
		
		ResponseTemplateVo res=new ResponseTemplateVo();
		Patients pat=prepo.findById(id).get();
		Invoices inv=rest.getForObject("http://localhost:8084/invoice/gtinv/" + pat.getId(), Invoices.class);
		res.setPat(pat);
		res.setInv(inv);
		return res;
		
	}
	
	
	
}
