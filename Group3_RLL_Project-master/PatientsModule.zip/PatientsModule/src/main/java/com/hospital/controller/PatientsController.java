package com.hospital.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Patients;
import com.hospital.service.PatientsService;
import com.hospital.vo.ResponseTemplateVo;

@RestController
@Scope("request")
public class PatientsController {

	@Autowired
	private PatientsService pser;
	
	@RequestMapping("/patients") 
	public String dumyMethod() { 
		return "Welcome to Patients portal"; 
	} 
	
	@PostMapping(value="/patient/inp", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.CREATED) 
	public Patients addPatient(@RequestBody Patients patients){
		return pser.addNewPatient(patients);
	}
	
	
	
	
	@PutMapping(value="/patient/uppp", produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.OK) 
	public Patients updatePwd(@RequestBody Patients patients){
		return pser.updatePatientPwd(patients);
	}
	
	
	@PutMapping(value="/patient/ep", produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.OK) 
	public Patients updatePatients(@RequestBody Patients patients){
		return pser.updatePatientsDetails(patients);
	}
	
	@DeleteMapping(value="/patient/rmp/{id}")
	@ResponseStatus(code=HttpStatus.NO_CONTENT) 
	public void removePatients(@PathVariable int id) {
		pser.removePatientDetails(id);
	}
	
	@GetMapping(value="/patient/gtp", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Patients> listPatients(){
		return pser.getAllPatients();
	}
	
	@GetMapping(value="/patient/gtp/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Patients getPatientsByid(@PathVariable int id) {
		return pser.getPatientsByid(id);
	}
	
	
	@GetMapping(value="/patient/gtpad/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseTemplateVo appointmentDetails(@PathVariable int id){
		return pser.getAppointmentDetails(id);
	}
	
	@GetMapping(value="/patient/gtbd/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseTemplateVo getBillingDetailsById(@PathVariable int id) {
		// TODO Auto-generated method stub
		return pser.getBillingDetailsById(id);
	}

	
}
