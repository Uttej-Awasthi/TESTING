package com.hospital.vo;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Appointment {

	private int aid ;
	private String address;
	private String doctor_name;
	private String doctor_specialization;
	@JsonFormat(pattern="dd/MM/yyyy")
	private Date ap_date  ;
	private String ap_status ;
	private String disease ;
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public String getDoctor_specialization() {
		return doctor_specialization;
	}
	public void setDoctor_specialization(String doctor_specialization) {
		this.doctor_specialization = doctor_specialization;
	}
	public Date getAp_date() {
		return ap_date;
	}
	public void setAp_date(Date ap_date) {
		this.ap_date = ap_date;
	}
	public String getAp_status() {
		return ap_status;
	}
	public void setAp_status(String ap_status) {
		this.ap_status = ap_status;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	public Appointment(int aid, String address, String doctor_name, String doctor_specialization, Date ap_date,
			String ap_status, String disease) {
		super();
		this.aid = aid;
		this.address = address;
		this.doctor_name = doctor_name;
		this.doctor_specialization = doctor_specialization;
		this.ap_date = ap_date;
		this.ap_status = ap_status;
		this.disease = disease;
	}
	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Appointment [aid=" + aid + ", address=" + address + ", doctor_name=" + doctor_name
				+ ", doctor_specialization=" + doctor_specialization + ", ap_date=" + ap_date + ", ap_status="
				+ ap_status + ", disease=" + disease + "]";
	}
	

}
