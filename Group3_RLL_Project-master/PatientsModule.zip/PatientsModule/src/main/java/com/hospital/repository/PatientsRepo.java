package com.hospital.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hospital.entity.Patients;


@Repository("patientsRepository")
@Scope("singleton")
public interface PatientsRepo extends JpaRepository<Patients,Integer> {

		
}
