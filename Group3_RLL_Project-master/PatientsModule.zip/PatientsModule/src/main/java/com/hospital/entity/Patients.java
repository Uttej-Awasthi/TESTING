package com.hospital.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Patients {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	private int p_id;
	private String p_name;
	private String p_age;
	private String p_email;
	private String p_password;
	private String p_location;
	private int aid;
	private int id;
	
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_age() {
		return p_age;
	}
	public void setP_age(String p_age) {
		this.p_age = p_age;
	}
	public String getP_email() {
		return p_email;
	}
	public void setP_email(String p_email) {
		this.p_email = p_email;
	}
	public String getP_password() {
		return p_password;
	}
	public void setP_password(String p_password) {
		this.p_password = p_password;
	}
	public String getP_location() {
		return p_location;
	}
	public void setP_location(String p_location) {
		this.p_location = p_location;
	}
	
	public Patients() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Patients(int p_id, String p_name, String p_age, String p_email, String p_password, String p_location,
			int aid, int id) {
		super();
		this.p_id = p_id;
		this.p_name = p_name;
		this.p_age = p_age;
		this.p_email = p_email;
		this.p_password = p_password;
		this.p_location = p_location;
		this.aid = aid;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Patients [p_id=" + p_id + ", p_name=" + p_name + ", p_age=" + p_age + ", p_email=" + p_email
				+ ", p_password=" + p_password + ", p_location=" + p_location + ", aid=" + aid + ", id=" + id + "]";
	}
	
			
}

