package com.hospital;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.hospital.entity.Patients;
import com.hospital.repository.PatientsRepo;

@SpringBootApplication
@EnableEurekaClient
public class PatientsModuleApplication implements CommandLineRunner{
	
	@Autowired
	private PatientsRepo rep;
	

	public static void main(String[] args) {
		SpringApplication.run(PatientsModuleApplication.class, args);
		System.out.println("patients module running.....");
		
		 
	}
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		rep.save(new Patients(1,"sam","25","abc@gmail.com","sam@123","Chennai",1,1));
		rep.save(new Patients(2,"tom","26","bcd@gmail.com","tom@123","Madurai",2,2));
		rep.save(new Patients(3,"ash","27","cde@gmail.com","ash@123","Thiruchy",3,3));
		rep.save(new Patients(4,"ron","28","efg@gmail.com","ron@123","Coimbatore",4,4));
		
		
	}

}
