package com.hospital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoicesModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
