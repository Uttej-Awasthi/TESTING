package com.hospital.service;


import java.util.List;

import com.hospital.entity.Invoices;

public interface IInvoiceService {

	Invoices saveInvoice(Invoices invoice);
	Invoices updateInvoice(Invoices invoice);
	void deleteInvoice(int id);
	Invoices findByIdInvoice(int id);
	List<Invoices> findAllInvoices();
	
}
