
package com.hospital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hospital.entity.Invoices;
import com.hospital.repository.InvoicesRepo;


@Service("invoicesService")
public class InvoicesService implements IInvoiceService{
	
	@Autowired
	@Qualifier("invoicesRepository")
	private InvoicesRepo rep;

	@Override
	public Invoices saveInvoice(Invoices invoice) {
		// TODO Auto-generated method stub
		return rep.save(invoice);
	}

	@Override
	public Invoices updateInvoice(Invoices invoice) {
		// TODO Auto-generated method stub
		return rep.save(invoice);
	}

	@Override
	public void deleteInvoice(int id) {
		// TODO Auto-generated method stub
		rep.deleteById(id);
	}

	@Override
	public Invoices findByIdInvoice(int id) {
		// TODO Auto-generated method stub
		return rep.findById(id);
	}

	@Override
	public List<Invoices> findAllInvoices() {
		// TODO Auto-generated method stub
		return rep.findAll();
	}

	
}
