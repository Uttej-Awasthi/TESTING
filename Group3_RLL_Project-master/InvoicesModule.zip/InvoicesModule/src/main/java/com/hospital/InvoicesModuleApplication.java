package com.hospital;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.hospital.entity.Invoices;
import com.hospital.repository.InvoicesRepo;

@SpringBootApplication
@EnableEurekaClient
public class InvoicesModuleApplication implements CommandLineRunner  {
	
	@Autowired
	private InvoicesRepo rep;

	public static void main(String[] args) {
		SpringApplication.run(InvoicesModuleApplication.class, args);
		System.out.println("invoices module is running.....");
	}

	@Override
	public void run(String... args) throws Exception {
		rep.save(new Invoices(1,1000,10000,500,11500));
		rep.save(new Invoices(2,200,1000,500,1700));
		rep.save(new Invoices(3,50000,40000,20000,110000));
		rep.save(new Invoices(4,100,200,250,550));
		
		
		
	}

}
