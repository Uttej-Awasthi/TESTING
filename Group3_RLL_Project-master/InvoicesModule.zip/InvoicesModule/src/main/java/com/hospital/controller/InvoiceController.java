package com.hospital.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Invoices;
import com.hospital.service.InvoicesService;

@RestController
@Scope("request")
public class InvoiceController {

	@Autowired
	private InvoicesService ser;
	
	@RequestMapping("/invoice") 
	public String dumyMethod() { 
		return "Welcome to Billing portal"; 
	} 
	
	@PostMapping(value="invoice/ininv", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.CREATED) 
	public Invoices saveInvoice(@RequestBody Invoices invoice) {
		
		return ser.saveInvoice(invoice);
	}
	
	@PutMapping(value="invoice/upinv", produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.OK) 
	public Invoices updateInvoice(@RequestBody Invoices invoice) {
		
		return ser.updateInvoice(invoice);
	}
	
	@DeleteMapping(value="invoice/rminv/{id}")
	@ResponseStatus(code=HttpStatus.NO_CONTENT) 
	public void deleteInvoice(@PathVariable int id) {
		// TODO Auto-generated method stub
		ser.deleteInvoice(id);
	}
	
	@GetMapping(value="invoice/gtinv/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Invoices findByIdInvoice(@PathVariable int id) {
		// TODO Auto-generated method stub
		return ser.findByIdInvoice(id);
	}
	
	@GetMapping(value="invoice/gtinv", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Invoices> findAllInvoices() {
		// TODO Auto-generated method stub
		return ser.findAllInvoices();
	}



}
