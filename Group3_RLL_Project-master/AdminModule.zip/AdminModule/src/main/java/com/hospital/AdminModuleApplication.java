package com.hospital;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.hospital.entity.Admin;
import com.hospital.repository.AdminRepo;

@SpringBootApplication
@EnableEurekaClient
public class AdminModuleApplication implements CommandLineRunner {
	
	@Autowired
	private AdminRepo rep;

	public static void main(String[] args) {
		SpringApplication.run(AdminModuleApplication.class, args);
		System.out.println("admin module running.....");
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		rep.save(new Admin(1,"aslam","aslam904@gmail.com","admin@123"));
		rep.save(new Admin(2,"admin","admin@gmail.com","admin@123"));
	}

}
