package com.hospital.repository;


import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hospital.entity.Admin;

@Repository("adminRepository")
@Scope("singleton")
public interface AdminRepo extends JpaRepository<Admin, Integer> {

	@Query(value=("select * from admin where admin.aname= ? "), nativeQuery = true)
	public Admin searchAdmin(String aname);
	
	
}
