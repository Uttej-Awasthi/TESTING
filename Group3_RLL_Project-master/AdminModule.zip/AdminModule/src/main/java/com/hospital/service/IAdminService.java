package com.hospital.service;


import java.util.List;

import com.hospital.entity.Admin;

public interface IAdminService {
	
	List<Admin> getAllAdmin();
	Admin updateAdmin(Admin admin);

}
