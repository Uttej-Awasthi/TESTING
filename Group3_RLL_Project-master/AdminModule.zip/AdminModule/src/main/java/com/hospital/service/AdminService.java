package com.hospital.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hospital.entity.Admin;
import com.hospital.repository.AdminRepo;

@Service("adminService")
public class AdminService implements IAdminService {

	@Autowired
	@Qualifier("adminRepository")
	AdminRepo arepo;
	
	
	@Override
	public List<Admin> getAllAdmin() {
		return arepo.findAll();
	}
	
	
	@Override
	public Admin updateAdmin(Admin admin)
	{
		Admin a1=arepo.searchAdmin(admin.getAname());
		a1.setApassword(admin.getApassword());
		arepo.save(a1);
		return a1;
	}
}
