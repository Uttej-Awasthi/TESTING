package com.hospital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hospital.entity.Appointment;
import com.hospital.repository.AppointmentRepo;

@Service("appointmentService")
public class AppointmentService implements IAppointmentService {
	
	@Autowired
	@Qualifier("appointmentRepository")
	private AppointmentRepo arepo;
	
	public List<Appointment> getAllAppointment(){
		return arepo.findAll();
	}
	
	public Appointment getByIdAppointment(int id){
		return arepo.findById(id).get();
	}
	
	public List<Appointment> getAllAppointmentBooked(){
		return arepo.getAppointmentBooked();
	}
	
	public List<Appointment> getAllAppointmentNotBooked(){
		return arepo.getAppointmentNotBooked();
	}
	
	public Appointment addNewAppointment(Appointment appointment){
		return arepo.save(appointment);
	}
	
	public Appointment updateAppointment(Appointment appointment) {
		Appointment a1=arepo.findById(appointment.getAid()).get();
		a1.setAddress(appointment.getAddress());
		a1.setDoctor_name(appointment.getDoctor_name());
		a1.setDoctor_specialization(appointment.getDoctor_specialization());
		a1.setAp_date(appointment.getAp_date());
		a1.setAp_status(appointment.getAp_status());
		a1.setDisease(appointment.getDisease());
		arepo.save(a1);
		return a1;
	}
	
	public void removeAppointmentDetails(int id){
		arepo.deleteById(id);
	}

	

}
