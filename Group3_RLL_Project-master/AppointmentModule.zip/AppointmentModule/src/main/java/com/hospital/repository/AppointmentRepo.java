package com.hospital.repository;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hospital.entity.Appointment;

@Repository("appointmentRepository")
@Scope("singleton")
public interface AppointmentRepo extends JpaRepository<Appointment,Integer> {

	
		@Query(value=("select * from appointment where appointment.ap_status= 'booked' "), nativeQuery = true)
		public List<Appointment> getAppointmentBooked();
		
		@Query(value=("select * from appointment where appointment.ap_status= 'unbooked' "), nativeQuery = true)
		public List<Appointment> getAppointmentNotBooked();
}
