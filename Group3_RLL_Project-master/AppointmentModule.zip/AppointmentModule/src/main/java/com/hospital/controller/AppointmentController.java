package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Appointment;
import com.hospital.service.AppointmentService;


@RestController
@Scope("request")
public class AppointmentController {
	
	@Autowired
	@Qualifier("appointmentService")
	private AppointmentService arepo;
	
	@RequestMapping("/appointment") 
	public String dumyMethod() { 
		return "Welcome to Appointment portal"; 
	} 
	
	
	@GetMapping(value="/appointment/gtap", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Appointment> getAllAppointment(){
		return arepo.getAllAppointment();
	}
	
	@GetMapping(value="/appointment/gtap/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Appointment getByIdAppointment(@PathVariable int id){
		return arepo.getByIdAppointment(id);
	}
	

	@GetMapping(value="/appointment/gtapb", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Appointment> getAllAppointmentBooked(){
		return arepo.getAllAppointmentBooked();
	}
	
	@GetMapping(value="/appointment/gtapub", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Appointment> getAllAppointmentNotBooked(){
		return arepo.getAllAppointmentNotBooked();
	}
	
	
	@PostMapping(value="/appointment/inap", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.CREATED) 
	public Appointment addNewAppointment(@RequestBody Appointment appointment){
		return arepo.addNewAppointment(appointment);
	}
	
	
	@PutMapping(value="/appointment/eap", produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.OK) 
	public Appointment updateAppointment(@RequestBody Appointment appointment)
	{
		return arepo.updateAppointment(appointment);
	}
	

	@DeleteMapping(value="/appointment/rmap/{id}")
	@ResponseStatus(code=HttpStatus.NO_CONTENT) 
	public void removeAppointmentDetails(@PathVariable int id){
		 arepo.removeAppointmentDetails(id);
	}


}
