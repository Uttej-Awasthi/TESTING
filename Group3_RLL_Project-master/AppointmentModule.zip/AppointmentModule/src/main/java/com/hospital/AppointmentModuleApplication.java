package com.hospital;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.hospital.entity.Appointment;
import com.hospital.repository.AppointmentRepo;

@SpringBootApplication
@EnableEurekaClient
public class AppointmentModuleApplication implements CommandLineRunner  {
	
	
	@Autowired
	private AppointmentRepo rep;

	public static void main(String[] args) {
		SpringApplication.run(AppointmentModuleApplication.class, args);
		System.out.println("appointment module riunning");
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		rep.save(new Appointment(1,"Tnagar Chennai","Sam","MBBS",new Date(26/10/22),"booked","fever"));
		rep.save(new Appointment(2,"Porur Chennai","Arun","MS",new Date(27/10/22),"booked","cold"));
		rep.save(new Appointment(3,"Poonamalee Chennai","Pradeep","MS",new Date(29/10/22),"unbooked","cancer"));
		rep.save(new Appointment(4,"Anna Nagar Chennai","Anwar","MS",new Date(16/10/22),"unbooked","stomach pain"));
		
	}

	

}
