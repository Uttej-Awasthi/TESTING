package com.hospital.service;

import java.util.List;

import com.hospital.entity.Appointment;

public interface IAppointmentService {

	List<Appointment> getAllAppointment();
	List<Appointment> getAllAppointmentBooked();
	List<Appointment> getAllAppointmentNotBooked();
	Appointment addNewAppointment(Appointment appointment);
	Appointment updateAppointment(Appointment appointment);
	Appointment getByIdAppointment(int id);
	void removeAppointmentDetails(int id);
	
}
