package com.hospital;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.hospital.entity.Doctor;
import com.hospital.repository.DoctorRepository;

@SpringBootApplication
@EnableEurekaClient
public class DoctorModuleApplication implements CommandLineRunner {
	
	@Autowired
	private DoctorRepository rep;

	public static void main(String[] args) {
		SpringApplication.run(DoctorModuleApplication.class, args);
		System.out.println("doctor module running...");
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		rep.save(new Doctor(1,"ross","ross904","MS","permanent"));
		rep.save(new Doctor(2,"ben","ben123","MBBS","hold"));
		rep.save(new Doctor(3,"arun","arun456","MS","hold"));
		rep.save(new Doctor(4,"pradeep","pradeep678","MBBS","permanent"));	
	}

}
