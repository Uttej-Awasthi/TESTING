package com.hospital.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Doctor;
import com.hospital.service.DoctorService;




@RestController
@Scope("request")
public class DoctorController {
	
	@Autowired
	@Qualifier("doctorService")
	private DoctorService doctorService ;
	
	@RequestMapping("/doctor") 
	public String dumyMethod() { 
		return "Welcome to Doctor portal"; 
	} 

	
	@PostMapping(value = "doctor/ind", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.CREATED) 
	public Doctor adddoctor(@RequestBody Doctor doctor) {
		return doctorService.save(doctor);
	}

	@PutMapping(value="doctor/upd", produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.OK) 
	public Doctor updateDoctor(@RequestBody Doctor doctor) {
		return doctorService.update(doctor);
	}
	
	@DeleteMapping(value="/doctor/rmd/{id}")
	@ResponseStatus(code=HttpStatus.NO_CONTENT) 
	public void deleteDoctor(@PathVariable int id) {
		doctorService.delete(id);
	}
	
	@GetMapping(value="/doctor/gtd", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctors(){
		return doctorService.getAllDoctors();
	}
	
	
	@GetMapping(value="/doctor/hldd/{status}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctorByStatusHold(@PathVariable String status) {
		return doctorService.getAllDoctorByStatusHold(status);
	}
	
	@GetMapping(value="/doctor/pntd/{status}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctorByStatusPermanent(@PathVariable String status) {
		return doctorService.getAllDoctorByStatusPermanent(status);
	}
	
	@GetMapping(value="/doctor/spld/{specialization}")
	public List<Doctor> getAllDoctorBySpecialization(@PathVariable String specialization) {
		return doctorService.getAllDoctorBySpecialization(specialization);
	}
	
	
	@GetMapping(value="doctor/gtd/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Doctor getDoctorById(@PathVariable int id) {
		return doctorService.getDoctorById(id);
	}
	

}

