package com.hospital.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hospital.entity.Doctor;
import com.hospital.repository.DoctorRepository;

@Service("doctorService")
public class DoctorService implements IDoctorService{

	@Autowired
	@Qualifier("doctorRepository")
	private DoctorRepository doctorRepository;
	
	@Override
	public Doctor save(Doctor doctor) {
	
		return doctorRepository.save(doctor);
	}

	@Override
	public Doctor update(Doctor doctor) {
		return doctorRepository.save(doctor);
	}

	@Override
	public void delete(int id) {
		doctorRepository.deleteById(id);
		
	}

	@Override
	public List<Doctor> getAllDoctors() {
		return doctorRepository.findAll();
	}

	@Override
	public List<Doctor> getAllDoctorByStatusHold(String status) {
		return doctorRepository.findByDoctorByStatusHold(status);
	}

	@Override
	public List<Doctor> getAllDoctorByStatusPermanent(String status) {
		return doctorRepository.findByDoctorByStatusPermanent(status);
	}

	@Override
	public List<Doctor> getAllDoctorBySpecialization(String specialization) {
		return doctorRepository.findByDoctorBySpecialization(specialization);
	}

	@Override
	public Doctor getDoctorById(int id) {
		return doctorRepository.findByDoctorId(id);
	}

	
}
