package com.hospital.service;


import java.util.List;

import com.hospital.entity.Doctor;


public interface IDoctorService {
	Doctor save(Doctor doctor);
	Doctor update(Doctor doctor);
    void delete(int id);
	List<Doctor> getAllDoctors();
	List<Doctor> getAllDoctorByStatusHold(String status);
	List<Doctor> getAllDoctorByStatusPermanent(String status);
	List<Doctor> getAllDoctorBySpecialization(String specialization);
	Doctor getDoctorById(int id);
}

	
	

