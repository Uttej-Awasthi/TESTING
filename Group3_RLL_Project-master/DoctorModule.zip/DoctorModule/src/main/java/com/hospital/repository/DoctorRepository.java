package com.hospital.repository;


import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hospital.entity.Doctor;


@Repository("doctorRepository")
@Scope("singleton")
public interface DoctorRepository extends JpaRepository<Doctor, Integer>{
	
	
	@Query(value=("select * from doctor where doctor.status= ? "), nativeQuery = true)
	List<Doctor> findByDoctorByStatusHold(String status);
	
	@Query(value=("select * from doctor where doctor.status= ? "), nativeQuery = true)
	List<Doctor> findByDoctorByStatusPermanent(String status);
	
	@Query(value=("select * from doctor where doctor.specialization= ? "), nativeQuery = true)
	List<Doctor> findByDoctorBySpecialization(String specialization);
	
	@Query(value=("select * from doctor where doctor.id= ? "), nativeQuery = true)
	Doctor findByDoctorId(int id);
	
}