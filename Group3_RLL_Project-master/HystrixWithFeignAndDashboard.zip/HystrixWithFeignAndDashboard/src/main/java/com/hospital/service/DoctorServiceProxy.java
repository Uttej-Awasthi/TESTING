package com.hospital.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.hospital.entity.Doctor;

@FeignClient(name="hms-service",fallback= DoctorProxyServiceFallback.class)
public interface DoctorServiceProxy {
	
	@GetMapping(value="/doctor/gtd", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctors();
	
	
	@GetMapping(value="/doctor/hldd/{status}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctorByStatusHold(@PathVariable String status);
	
	@GetMapping(value="/doctor/pntd/{status}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctorByStatusPermanent(@PathVariable String status); 
	
	@GetMapping(value="/doctor/spld/{specialization}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctorBySpecialization(@PathVariable String specialization);
	
	
	@GetMapping(value="doctor/gtd/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Doctor getDoctorById(@PathVariable int id); 


}
