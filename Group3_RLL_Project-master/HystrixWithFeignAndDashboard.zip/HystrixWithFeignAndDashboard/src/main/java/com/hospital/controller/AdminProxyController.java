package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Admin;
import com.hospital.service.AdminServiceProxy;

@RestController
public class AdminProxyController {

	@Autowired
	private AdminServiceProxy ser;

	@GetMapping(value="/admin/gta")
	public List<Admin> listAdmin() {
		// TODO Auto-generated method stub
		return ser.listAdmin();
}
}
