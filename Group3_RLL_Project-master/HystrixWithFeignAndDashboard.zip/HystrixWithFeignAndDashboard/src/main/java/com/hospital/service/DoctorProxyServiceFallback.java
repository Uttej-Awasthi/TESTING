package com.hospital.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.hospital.entity.Doctor;

@Component
public class DoctorProxyServiceFallback implements DoctorServiceProxy {

	@Override
	public List<Doctor> getAllDoctors() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Doctor());
	}

	@Override
	public List<Doctor> getAllDoctorByStatusHold(String status) {
		// TODO Auto-generated method stub
		return Arrays.asList(new Doctor());
	}

	@Override
	public List<Doctor> getAllDoctorByStatusPermanent(String status) {
		// TODO Auto-generated method stub
		return Arrays.asList(new Doctor());
	}

	@Override
	public List<Doctor> getAllDoctorBySpecialization(String specialization) {
		// TODO Auto-generated method stub
		return Arrays.asList(new Doctor());
	}

	@Override
	public Doctor getDoctorById(int id) {
		// TODO Auto-generated method stub
		return new Doctor();
	}

}
