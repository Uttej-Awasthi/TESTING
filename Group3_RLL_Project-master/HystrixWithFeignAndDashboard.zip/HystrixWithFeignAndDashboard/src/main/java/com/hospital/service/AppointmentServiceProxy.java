package com.hospital.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.hospital.entity.Appointment;

@FeignClient(name="hms-service",fallback= AppointmentProxyServiceFallback.class)
public interface AppointmentServiceProxy {

	@GetMapping(value="/appointment/gtap", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Appointment> getAllAppointment();
	
	@GetMapping(value="/appointment/gtap/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Appointment getByIdAppointment(@PathVariable int id);
	

	@GetMapping(value="/appointment/gtapb", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Appointment> getAllAppointmentBooked();
	
	@GetMapping(value="/appointment/gtapub", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Appointment> getAllAppointmentNotBooked();
	

}
