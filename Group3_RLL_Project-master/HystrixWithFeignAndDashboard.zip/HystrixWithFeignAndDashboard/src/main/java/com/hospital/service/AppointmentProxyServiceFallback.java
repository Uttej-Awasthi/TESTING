package com.hospital.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.hospital.entity.Appointment;

@Component
public class AppointmentProxyServiceFallback implements AppointmentServiceProxy {

	@Override
	public List<Appointment> getAllAppointment() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Appointment());
	}

	@Override
	public Appointment getByIdAppointment(int id) {
		// TODO Auto-generated method stub
		return new Appointment();
	}

	@Override
	public List<Appointment> getAllAppointmentBooked() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Appointment());
	}

	@Override
	public List<Appointment> getAllAppointmentNotBooked() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Appointment());
	}

	
}
