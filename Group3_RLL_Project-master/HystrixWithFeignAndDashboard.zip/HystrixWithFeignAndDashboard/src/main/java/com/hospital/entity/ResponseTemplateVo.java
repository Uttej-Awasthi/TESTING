package com.hospital.entity;


public class ResponseTemplateVo {
	
	private Patients pat;
	private Appointment app;
	private Invoices inv;
	public Patients getPat() {
		return pat;
	}
	public void setPat(Patients pat) {
		this.pat = pat;
	}
	public Appointment getApp() {
		return app;
	}
	public void setApp(Appointment app) {
		this.app = app;
	}
	public Invoices getInv() {
		return inv;
	}
	public void setInv(Invoices inv) {
		this.inv = inv;
	}
	public ResponseTemplateVo(Patients pat, Appointment app, Invoices inv) {
		super();
		this.pat = pat;
		this.app = app;
		this.inv = inv;
	}
	public ResponseTemplateVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "ResponseTemplateVo [pat=" + pat + ", app=" + app + ", inv=" + inv + "]";
	}
	
	

}
