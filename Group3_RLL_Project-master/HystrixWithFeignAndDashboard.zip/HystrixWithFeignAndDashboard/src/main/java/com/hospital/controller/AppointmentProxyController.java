package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Appointment;
import com.hospital.service.AppointmentServiceProxy;

@RestController
public class AppointmentProxyController {
	
	@Autowired
	private AppointmentServiceProxy arepo;
	
	@GetMapping(value="/appointment/gtap", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Appointment> getAllAppointment(){
		return arepo.getAllAppointment();
	}
	
	@GetMapping(value="/appointment/gtap/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Appointment getByIdAppointment(@PathVariable int id){
		return arepo.getByIdAppointment(id);
	}
	

	@GetMapping(value="/appointment/gtapb", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Appointment> getAllAppointmentBooked(){
		return arepo.getAllAppointmentBooked();
	}
	
	@GetMapping(value="/appointment/gtapub", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Appointment> getAllAppointmentNotBooked(){
		return arepo.getAllAppointmentNotBooked();
	}
	


}
