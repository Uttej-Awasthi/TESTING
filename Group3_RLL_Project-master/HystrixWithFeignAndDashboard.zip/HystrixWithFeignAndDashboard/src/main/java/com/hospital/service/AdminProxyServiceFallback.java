package com.hospital.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;
import com.hospital.entity.Admin;

@Component
public class AdminProxyServiceFallback implements AdminServiceProxy{


	@Override
	public List<Admin> listAdmin() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Admin());
	}

	
}
