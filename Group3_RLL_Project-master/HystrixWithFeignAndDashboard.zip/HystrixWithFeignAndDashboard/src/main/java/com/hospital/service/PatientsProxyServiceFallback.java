package com.hospital.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.hospital.entity.Patients;
import com.hospital.entity.ResponseTemplateVo;


@Component
public class PatientsProxyServiceFallback implements PatientsServiceProxy{

	@Override
	public List<Patients> listPatients() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Patients());
	}

	@Override
	public Patients getPatientsByid(int id) {
		// TODO Auto-generated method stub
		return new Patients();
	}

	@Override
	public ResponseTemplateVo appointmentDetails(int id) {
		// TODO Auto-generated method stub
		return new ResponseTemplateVo();
	}

	@Override
	public ResponseTemplateVo getBillingDetailsById(int id) {
		// TODO Auto-generated method stub
		return new ResponseTemplateVo();
	}

}
