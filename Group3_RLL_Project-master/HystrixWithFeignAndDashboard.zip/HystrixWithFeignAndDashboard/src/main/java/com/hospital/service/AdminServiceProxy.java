package com.hospital.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;

import com.hospital.entity.Admin;


@FeignClient(name="hms-service",fallback= AdminProxyServiceFallback.class)
public interface AdminServiceProxy {

	@GetMapping(value="/admin/gta", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Admin> listAdmin();
	
}
