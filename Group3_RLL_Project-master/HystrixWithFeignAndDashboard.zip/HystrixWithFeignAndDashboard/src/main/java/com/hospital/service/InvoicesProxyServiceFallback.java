package com.hospital.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.hospital.entity.Invoices;


@Component
public class InvoicesProxyServiceFallback implements InvoicesServiceProxy{

	@Override
	public Invoices findByIdInvoice(int id) {
		// TODO Auto-generated method stub
		return new Invoices();
	}

	@Override
	public List<Invoices> findAllInvoices() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Invoices());
	}

}
