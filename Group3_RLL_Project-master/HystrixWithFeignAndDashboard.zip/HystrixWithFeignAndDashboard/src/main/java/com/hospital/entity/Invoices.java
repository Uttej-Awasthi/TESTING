package com.hospital.entity;






public class Invoices {

	
	private int id;
	private int medicineCost;
	private int roomCost;
	private int doctorCharges;
	private int totalCharges;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMedicineCost() {
		return medicineCost;
	}
	public void setMedicineCost(int medicineCost) {
		this.medicineCost = medicineCost;
	}
	public int getRoomCost() {
		return roomCost;
	}
	public void setRoomCost(int roomCost) {
		this.roomCost = roomCost;
	}
	public int getDoctorCharges() {
		return doctorCharges;
	}
	public void setDoctorCharges(int doctorCharges) {
		this.doctorCharges = doctorCharges;
	}
	public int getTotalCharges() {
		return totalCharges;
	}
	public void setTotalCharges(int totalCharges) {
		this.totalCharges = totalCharges;
	}
	public Invoices(int id, int medicineCost, int roomCost, int doctorCharges, int totalCharges) {
		super();
		this.id = id;
		this.medicineCost = medicineCost;
		this.roomCost = roomCost;
		this.doctorCharges = doctorCharges;
		this.totalCharges = totalCharges;
	}
	public Invoices() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Invoices [id=" + id + ", medicineCost=" + medicineCost + ", roomCost=" + roomCost + ", doctorCharges="
				+ doctorCharges + ", totalCharges=" + totalCharges + "]";
	}
	
		
		
}
