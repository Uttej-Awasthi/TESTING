package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Doctor;
import com.hospital.service.DoctorServiceProxy;

@RestController
public class DoctorProxyController {
	
	@Autowired
	private DoctorServiceProxy doctorService;
	
	@GetMapping(value="/doctor/gtd", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctors(){
		return doctorService.getAllDoctors();
	}
	
	
	@GetMapping(value="/doctor/hldd/{status}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctorByStatusHold(@PathVariable String status) {
		return doctorService.getAllDoctorByStatusHold(status);
	}
	
	@GetMapping(value="/doctor/pntd/{status}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Doctor> getAllDoctorByStatusPermanent(@PathVariable String status) {
		return doctorService.getAllDoctorByStatusPermanent(status);
	}
	
	@GetMapping(value="/doctor/spld/{specialization}")
	public List<Doctor> getAllDoctorBySpecialization(@PathVariable String specialization) {
		return doctorService.getAllDoctorBySpecialization(specialization);
	}
	
	
	@GetMapping(value="doctor/gtd/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Doctor getDoctorById(@PathVariable int id) {
		return doctorService.getDoctorById(id);
	}
	


}
