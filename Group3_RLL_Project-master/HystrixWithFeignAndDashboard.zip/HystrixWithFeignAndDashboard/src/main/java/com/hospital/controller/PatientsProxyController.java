package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Patients;
import com.hospital.service.PatientsServiceProxy;
import com.hospital.entity.ResponseTemplateVo;

@RestController
public class PatientsProxyController {
	
	@Autowired
	private PatientsServiceProxy pser;
	

	@GetMapping(value="/patient/gtp", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Patients> listPatients(){
		return pser.listPatients();
	}
	
	@GetMapping(value="/patient/gtp/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Patients getPatientsByid(@PathVariable int id) {
		return pser.getPatientsByid(id);
	}
	
	
	@GetMapping(value="/patient/gtpad/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseTemplateVo appointmentDetails(@PathVariable int id){
		return pser.appointmentDetails(id);
	}
	
	@GetMapping(value="/patient/gtbd/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseTemplateVo getBillingDetailsById(@PathVariable int id) {
		// TODO Auto-generated method stub
		return pser.getBillingDetailsById(id);
	}


}
