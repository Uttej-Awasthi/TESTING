package com.hospital.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.hospital.entity.Patients;
import com.hospital.entity.ResponseTemplateVo;

@FeignClient(name="hms-service",fallback= PatientsProxyServiceFallback.class)
public interface PatientsServiceProxy {
	
	@GetMapping(value="/patient/gtp", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Patients> listPatients();
	
	@GetMapping(value="/patient/gtp/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Patients getPatientsByid(@PathVariable int id);
	
	
	@GetMapping(value="/patient/gtpad/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseTemplateVo appointmentDetails(@PathVariable int id);
	
	@GetMapping(value="/patient/gtbd/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseTemplateVo getBillingDetailsById(@PathVariable int id);


}
