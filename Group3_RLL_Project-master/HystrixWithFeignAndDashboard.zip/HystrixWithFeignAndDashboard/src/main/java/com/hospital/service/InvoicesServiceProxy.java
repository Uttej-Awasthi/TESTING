package com.hospital.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.hospital.entity.Invoices;

@FeignClient(name="hms-service",fallback= InvoicesProxyServiceFallback.class)
public interface InvoicesServiceProxy {
	
	@GetMapping(value="invoice/gtinv/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Invoices findByIdInvoice(@PathVariable int id); 
	
	@GetMapping(value="invoice/gtinv", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Invoices> findAllInvoices(); 


}
