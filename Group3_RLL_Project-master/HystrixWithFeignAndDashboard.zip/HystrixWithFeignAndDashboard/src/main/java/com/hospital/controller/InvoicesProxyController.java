package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.Invoices;
import com.hospital.service.InvoicesServiceProxy;

@RestController
public class InvoicesProxyController {
	
	@Autowired
	private InvoicesServiceProxy ser;
	
	@GetMapping(value="invoice/gtinv/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Invoices findByIdInvoice(@PathVariable int id) {
		// TODO Auto-generated method stub
		return ser.findByIdInvoice(id);
	}
	
	@GetMapping(value="invoice/gtinv", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Invoices> findAllInvoices() {
		// TODO Auto-generated method stub
		return ser.findAllInvoices();
	}


}
